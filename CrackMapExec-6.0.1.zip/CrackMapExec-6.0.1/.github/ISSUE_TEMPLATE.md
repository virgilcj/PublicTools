## Steps to reproduce

1. ...
2. ...

## Command string used

## CME verbose output (using the --verbose flag)

## CME Version (cme --version)

## OS

## Target OS

## Detailed issue explanation
