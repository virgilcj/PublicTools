from rich.console import Console

cme_console = Console(soft_wrap=True, tab_size=4)
