[#] Usage : PePacker.exe <Input x64 exe> <*Output*> <*Optional Features*>
[#] Output :
              -d : Output The Packed Pe As A x64 Dll File
              -e : Output The Packed Pe As A x64 Exe File (Default)
[#] Features :
              -h : Hide The Console - /SUBSYSTEM:WINDOWS



Example:


PePacker.exe mimikatz.exe			: generate exe packed file
PePacker.exe mimikatz.exe -e			: generate exe packed file
PePacker.exe mimikatz.exe -e	-h		: generate hidden exe packed file
PePacker.exe mimikatz.exe -d			: generate dll output



The generated dll can be executed using 2 ways:
1- using command line, for example: "rundll32.exe DllPP64.dll Atom"
	- Using "Atom" is a must to run your payload - this is the name if the exported function in the dll
2- can be hijacked / injected into other process	